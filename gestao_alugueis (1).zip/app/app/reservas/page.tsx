
import { getServerSession } from 'next-auth';
import { redirect } from 'next/navigation';
import { DashboardLayout } from '@/components/dashboard-layout';
import { ReservasCalendar } from '@/components/reservas-calendar';

export default async function ReservasPage() {
  const session = await getServerSession();

  if (!session) {
    redirect('/login');
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Gestão de Reservas</h1>
            <p className="text-muted-foreground">
              Calendário visual e controle completo das reservas
            </p>
          </div>
        </div>
        <ReservasCalendar />
      </div>
    </DashboardLayout>
  );
}
