
import { getServerSession } from 'next-auth';
import { redirect } from 'next/navigation';
import { DashboardLayout } from '@/components/dashboard-layout';
import { HospedesManager } from '@/components/hospedes-manager';

export default async function HospedesPage() {
  const session = await getServerSession();

  if (!session) {
    redirect('/login');
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">CRM de Hóspedes</h1>
            <p className="text-muted-foreground">
              Cadastro e histórico completo dos seus hóspedes
            </p>
          </div>
        </div>
        <HospedesManager />
      </div>
    </DashboardLayout>
  );
}
