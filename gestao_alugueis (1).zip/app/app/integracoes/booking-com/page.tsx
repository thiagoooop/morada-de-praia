
'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowLeft, Plug, Unplug, CheckCircle2, AlertCircle, Calendar, RefreshCw } from 'lucide-react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { useToast } from '@/components/ui/use-toast';

interface Apartamento {
  id: string;
  nome: string;
}

interface AnuncioExterno {
  id: string;
  nome: string;
}

interface MapeamentoApartamento {
  id: string;
  apartamentoId: string;
  idExterno: string;
  nomeExterno: string;
}

interface Integracao {
  id: string;
  plataforma: string;
  status: 'DESCONECTADA' | 'CONECTADA' | 'ERRO' | 'SINCRONIZANDO';
  ultimaSync: string | null;
  ativa: boolean;
  mapeamentos: MapeamentoApartamento[];
}

export default function BookingIntegracaoPage() {
  const [integracao, setIntegracao] = useState<Integracao | null>(null);
  const [apartamentos, setApartamentos] = useState<Apartamento[]>([]);
  const [anunciosExternos, setAnunciosExternos] = useState<AnuncioExterno[]>([]);
  const [mapeamentos, setMapeamentos] = useState<Record<string, string>>({});
  const [syncAtiva, setSyncAtiva] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchDados();
  }, []);

  const fetchDados = async () => {
    try {
      const [integracaoRes, apartamentosRes] = await Promise.all([
        fetch('/api/integracoes/booking-com'),
        fetch('/api/apartamentos'),
      ]);

      if (integracaoRes.ok) {
        const integracaoData = await integracaoRes.json();
        setIntegracao(integracaoData);
        setSyncAtiva(integracaoData?.ativa || false);
        
        // Converter mapeamentos para o formato do estado
        const mapeamentosMap: Record<string, string> = {};
        integracaoData?.mapeamentos?.forEach((m: MapeamentoApartamento) => {
          mapeamentosMap[m.apartamentoId] = m.idExterno;
        });
        setMapeamentos(mapeamentosMap);
      }

      if (apartamentosRes.ok) {
        const apartamentosData = await apartamentosRes.json();
        setApartamentos(apartamentosData);
      }

      // Simular anúncios externos do Booking.com
      setAnunciosExternos([
        { id: 'booking_001', nome: 'Ocean View Apartment - Copacabana Beach' },
        { id: 'booking_002', nome: 'Modern Loft in Ipanema' },
        { id: 'booking_003', nome: 'Luxury Penthouse - Barra da Tijuca' },
        { id: 'booking_004', nome: 'Cozy Studio near Leblon Beach' },
      ]);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
      toast({
        title: 'Erro',
        description: 'Não foi possível carregar os dados da integração.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const conectarBooking = async () => {
    setIsSaving(true);
    try {
      const response = await fetch('/api/integracoes/booking-com/conectar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: 'demo_token_booking' }),
      });

      if (response.ok) {
        const data = await response.json();
        setIntegracao(data);
        toast({
          title: 'Sucesso!',
          description: 'Conta do Booking.com conectada com sucesso.',
        });
      }
    } catch (error) {
      console.error('Erro ao conectar:', error);
      toast({
        title: 'Erro',
        description: 'Falha ao conectar com o Booking.com.',
        variant: 'destructive',
      });
    } finally {
      setIsSaving(false);
    }
  };

  const desconectarBooking = async () => {
    setIsSaving(true);
    try {
      const response = await fetch('/api/integracoes/booking-com/desconectar', {
        method: 'POST',
      });

      if (response.ok) {
        setIntegracao(null);
        setMapeamentos({});
        setSyncAtiva(false);
        toast({
          title: 'Desconectado',
          description: 'Conta do Booking.com desconectada.',
        });
      }
    } catch (error) {
      console.error('Erro ao desconectar:', error);
      toast({
        title: 'Erro',
        description: 'Falha ao desconectar do Booking.com.',
        variant: 'destructive',
      });
    } finally {
      setIsSaving(false);
    }
  };

  const salvarConfiguracoes = async () => {
    setIsSaving(true);
    try {
      const response = await fetch('/api/integracoes/booking-com/configurar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mapeamentos,
          ativa: syncAtiva,
        }),
      });

      if (response.ok) {
        toast({
          title: 'Configurações salvas!',
          description: 'As configurações foram atualizadas com sucesso.',
        });
        fetchDados(); // Recarregar dados
      }
    } catch (error) {
      console.error('Erro ao salvar:', error);
      toast({
        title: 'Erro',
        description: 'Falha ao salvar configurações.',
        variant: 'destructive',
      });
    } finally {
      setIsSaving(false);
    }
  };

  const getStatusBadge = (status: string) => {
    const config = {
      CONECTADA: { label: 'Conectada', icon: CheckCircle2, className: 'bg-green-100 text-green-800' },
      DESCONECTADA: { label: 'Desconectada', icon: AlertCircle, className: 'bg-gray-100 text-gray-800' },
      ERRO: { label: 'Erro', icon: AlertCircle, className: 'bg-red-100 text-red-800' },
      SINCRONIZANDO: { label: 'Sincronizando', icon: RefreshCw, className: 'bg-blue-100 text-blue-800' },
    };

    const statusConfig = config[status as keyof typeof config];
    const Icon = statusConfig.icon;

    return (
      <Badge className={statusConfig.className}>
        <Icon className="h-3 w-3 mr-1" />
        {statusConfig.label}
      </Badge>
    );
  };

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-muted-foreground">Carregando configurações...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      {/* Header */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center gap-4"
      >
        <Link href="/integracoes">
          <Button variant="outline" size="icon">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center text-white font-bold text-lg">
            B
          </div>
          <div>
            <h1 className="text-2xl font-bold">Integração Booking.com</h1>
            <p className="text-muted-foreground">Configure a sincronização com o Booking.com</p>
          </div>
        </div>
      </motion.div>

      {/* Status da Conexão */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Status da Conexão
              {integracao && getStatusBadge(integracao.status)}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {integracao ? (
              <div className="space-y-4">
                <div className="text-sm space-y-2">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Última sincronização:</span>
                    <span>
                      {integracao.ultimaSync 
                        ? new Date(integracao.ultimaSync).toLocaleString('pt-BR')
                        : 'Nunca sincronizado'
                      }
                    </span>
                  </div>
                </div>
                <Button 
                  variant="destructive" 
                  onClick={desconectarBooking}
                  disabled={isSaving}
                >
                  <Unplug className="h-4 w-4 mr-2" />
                  {isSaving ? 'Desconectando...' : 'Desconectar Conta'}
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                <p className="text-muted-foreground">
                  Conecte sua conta do Booking.com para sincronizar reservas automaticamente.
                </p>
                <Button onClick={conectarBooking} disabled={isSaving}>
                  <Plug className="h-4 w-4 mr-2" />
                  {isSaving ? 'Conectando...' : 'Conectar com Booking.com'}
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Configurações de Sincronização */}
      {integracao && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card>
            <CardHeader>
              <CardTitle>Configurações de Sincronização</CardTitle>
              <CardDescription>
                Configure como as reservas serão sincronizadas entre as plataformas
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label htmlFor="sync-ativa">Sincronização Automática</Label>
                  <p className="text-sm text-muted-foreground">
                    Importe reservas do Booking.com automaticamente
                  </p>
                </div>
                <Switch
                  id="sync-ativa"
                  checked={syncAtiva}
                  onCheckedChange={setSyncAtiva}
                />
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}

      {/* Mapeamento de Apartamentos */}
      {integracao && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card>
            <CardHeader>
              <CardTitle>Mapeamento de Apartamentos</CardTitle>
              <CardDescription>
                Vincule seus apartamentos aos anúncios correspondentes no Booking.com
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {apartamentos.map((apartamento) => (
                <div key={apartamento.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex-1">
                    <Label className="font-medium">{apartamento.nome}</Label>
                    <p className="text-sm text-muted-foreground">Morada de Praia</p>
                  </div>
                  <div className="flex-1 max-w-xs">
                    <Select
                      value={mapeamentos[apartamento.id] || ''}
                      onValueChange={(value) => setMapeamentos(prev => ({
                        ...prev,
                        [apartamento.id]: value === 'none' ? '' : value
                      }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecionar anúncio do Booking.com" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">Nenhum anúncio</SelectItem>
                        {anunciosExternos.map((anuncio) => (
                          <SelectItem key={anuncio.id} value={anuncio.id}>
                            {anuncio.nome}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              ))}
              
              <div className="pt-4">
                <Button onClick={salvarConfiguracoes} disabled={isSaving}>
                  {isSaving ? 'Salvando...' : 'Salvar Configurações'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}
    </div>
  );
}
