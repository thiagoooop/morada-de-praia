
'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Plug, Calendar, AlertCircle, CheckCircle2, Settings } from 'lucide-react';
import Link from 'next/link';
import { motion } from 'framer-motion';

interface Integracao {
  id: string;
  plataforma: 'AIRBNB' | 'BOOKING_COM';
  nomeConexao: string;
  status: 'DESCONECTADA' | 'CONECTADA' | 'ERRO' | 'SINCRONIZANDO';
  ultimaSync: string | null;
  ativa: boolean;
}

const plataformasConfig = {
  AIRBNB: {
    nome: 'Airbnb',
    logo: 'https://cdn.pixabay.com/photo/2018/05/08/21/28/airbnb-3384008_960_720.png',
    descricao: 'Sincronize suas reservas do Airbnb automaticamente',
    cor: 'bg-red-500',
  },
  BOOKING_COM: {
    nome: 'Booking.com',
    logo: 'https://logospng.org/download/booking.com/booking-com-4096.png',
    descricao: 'Importe reservas do Booking.com em tempo real',
    cor: 'bg-blue-600',
  },
};

export default function IntegracoesPage() {
  const [integracoes, setIntegracoes] = useState<Integracao[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchIntegracoes();
  }, []);

  const fetchIntegracoes = async () => {
    try {
      const response = await fetch('/api/integracoes');
      if (response.ok) {
        const data = await response.json();
        setIntegracoes(data);
      }
    } catch (error) {
      console.error('Erro ao carregar integrações:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      CONECTADA: { label: 'Conectada', variant: 'default' as const, icon: CheckCircle2, color: 'text-green-600' },
      DESCONECTADA: { label: 'Desconectada', variant: 'secondary' as const, icon: AlertCircle, color: 'text-gray-500' },
      ERRO: { label: 'Erro', variant: 'destructive' as const, icon: AlertCircle, color: 'text-red-600' },
      SINCRONIZANDO: { label: 'Sincronizando', variant: 'outline' as const, icon: Calendar, color: 'text-blue-600' },
    };

    const config = statusConfig[status as keyof typeof statusConfig];
    const Icon = config.icon;

    return (
      <Badge variant={config.variant} className="flex items-center gap-1">
        <Icon className={`h-3 w-3 ${config.color}`} />
        {config.label}
      </Badge>
    );
  };

  const formatUltimaSync = (data: string | null) => {
    if (!data) return 'Nunca sincronizado';
    
    const agora = new Date();
    const sync = new Date(data);
    const diffHoras = Math.floor((agora.getTime() - sync.getTime()) / (1000 * 60 * 60));
    
    if (diffHoras < 1) return 'Sincronizado há poucos minutos';
    if (diffHoras < 24) return `Sincronizado há ${diffHoras}h`;
    
    return sync.toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  if (isLoading) {
    return (
      <div className="max-w-6xl mx-auto p-6">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-muted-foreground">Carregando integrações...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-8">
      {/* Header */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center space-y-4"
      >
        <div className="flex items-center justify-center gap-3">
          <Plug className="h-8 w-8 text-primary" />
          <h1 className="text-3xl font-bold">Integrações</h1>
        </div>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Conecte suas contas para sincronizar reservas automaticamente
        </p>
      </motion.div>

      {/* Plataformas Grid */}
      <div className="grid md:grid-cols-2 gap-6">
        {Object.entries(plataformasConfig).map(([key, config], index) => {
          const integracao = integracoes.find(i => i.plataforma === key);
          const isConectada = integracao?.status === 'CONECTADA';
          
          return (
            <motion.div
              key={key}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="h-full hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`w-12 h-12 rounded-lg ${config.cor} flex items-center justify-center text-white font-bold text-lg`}>
                        {config.nome.charAt(0)}
                      </div>
                      <div>
                        <CardTitle className="text-xl">{config.nome}</CardTitle>
                        <CardDescription>{config.descricao}</CardDescription>
                      </div>
                    </div>
                    {integracao && getStatusBadge(integracao.status)}
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  {integracao && (
                    <div className="text-sm text-muted-foreground">
                      <div className="flex justify-between">
                        <span>Última sincronização:</span>
                        <span>{formatUltimaSync(integracao.ultimaSync)}</span>
                      </div>
                    </div>
                  )}
                  
                  <div className="flex gap-2">
                    {isConectada ? (
                      <Link href={`/integracoes/${key.toLowerCase().replace('_', '-')}`} className="flex-1">
                        <Button variant="outline" className="w-full">
                          <Settings className="h-4 w-4 mr-2" />
                          Gerenciar
                        </Button>
                      </Link>
                    ) : (
                      <Link href={`/integracoes/${key.toLowerCase().replace('_', '-')}`} className="flex-1">
                        <Button className="w-full">
                          <Plug className="h-4 w-4 mr-2" />
                          Conectar
                        </Button>
                      </Link>
                    )}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>

      {/* Stats resumo */}
      {integracoes.length > 0 && (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-4"
        >
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-primary">{integracoes.filter(i => i.status === 'CONECTADA').length}</div>
              <div className="text-sm text-muted-foreground">Integração(ões) ativa(s)</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-primary">{integracoes.filter(i => i.ultimaSync).length}</div>
              <div className="text-sm text-muted-foreground">Sincronizada(s) hoje</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-primary">0</div>
              <div className="text-sm text-muted-foreground">Reservas importadas hoje</div>
            </CardContent>
          </Card>
        </motion.div>
      )}
    </div>
  );
}
