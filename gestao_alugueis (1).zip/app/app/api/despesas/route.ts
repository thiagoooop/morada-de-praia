
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const despesas = await prisma.despesa.findMany({
      include: {
        reserva: {
          include: {
            apartamento: {
              select: { nome: true }
            }
          }
        }
      },
      orderBy: { data: 'desc' }
    });

    // Converter Decimal para number
    const despesasFormatted = despesas.map(despesa => ({
      ...despesa,
      valor: Number(despesa.valor)
    }));

    return NextResponse.json(despesasFormatted);
  } catch (error) {
    console.error('Erro ao buscar despesas:', error);
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const data = await request.json();
    
    const despesa = await prisma.despesa.create({
      data: {
        descricao: data.descricao,
        valor: parseFloat(data.valor),
        data: new Date(data.data),
        categoria: data.categoria,
        reservaId: data.reservaId || null
      }
    });

    // Converter Decimal para number
    const despesaFormatted = {
      ...despesa,
      valor: Number(despesa.valor)
    };

    return NextResponse.json(despesaFormatted, { status: 201 });
  } catch (error) {
    console.error('Erro ao criar despesa:', error);
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
