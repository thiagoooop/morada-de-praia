
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { format, startOfMonth, endOfMonth, addDays, differenceInDays } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const now = new Date();
    const startMonth = startOfMonth(now);
    const endMonth = endOfMonth(now);

    // Buscar apartamentos com status atual
    const apartamentos = await prisma.apartamento.findMany({
      where: { ativo: true },
      include: {
        reservas: {
          where: {
            dataInicio: { lte: now },
            dataFim: { gte: now },
            status: { in: ['CONFIRMADA', 'CHECK_IN'] }
          },
          include: {
            hospede: true
          },
          orderBy: { dataFim: 'asc' }
        }
      }
    });

    // Preparar dados dos apartamentos
    const apartamentosData = await Promise.all(apartamentos.map(async (apt) => {
      const reservaAtual = apt.reservas[0];
      
      // Buscar próxima reserva se apartamento está vago
      let proximaReserva = null;
      if (!reservaAtual) {
        proximaReserva = await prisma.reserva.findFirst({
          where: {
            apartamentoId: apt.id,
            dataInicio: { gte: now },
            status: 'CONFIRMADA'
          },
          include: { hospede: true },
          orderBy: { dataInicio: 'asc' }
        });
      }

      return {
        id: apt.id,
        nome: apt.nome,
        status: reservaAtual ? 'ocupado' as const : 'vago' as const,
        hospedeAtual: reservaAtual?.hospede?.nome,
        proximoCheckOut: reservaAtual ? format(reservaAtual.dataFim, "dd/MM 'às' HH:mm", { locale: ptBR }) : undefined,
        proximoCheckIn: proximaReserva ? format(proximaReserva.dataInicio, "dd/MM 'às' HH:mm", { locale: ptBR }) : undefined,
      };
    }));

    // Buscar próximos eventos (check-ins e check-outs)
    const proximasReservas = await prisma.reserva.findMany({
      where: {
        OR: [
          { 
            dataInicio: { 
              gte: now, 
              lte: addDays(now, 7) 
            },
            status: 'CONFIRMADA'
          },
          { 
            dataFim: { 
              gte: now, 
              lte: addDays(now, 7) 
            },
            status: { in: ['CONFIRMADA', 'CHECK_IN'] }
          }
        ]
      },
      include: {
        apartamento: true,
        hospede: true
      },
      orderBy: [
        { dataInicio: 'asc' },
        { dataFim: 'asc' }
      ]
    });

    const proximosEventos: Array<{
      id: string;
      tipo: 'check-in' | 'check-out';
      apartamento: string;
      hospede: string;
      data: string;
    }> = [];

    proximasReservas.forEach(reserva => {
      // Check-in
      if (reserva.dataInicio >= now && reserva.status === 'CONFIRMADA') {
        proximosEventos.push({
          id: `${reserva.id}-checkin`,
          tipo: 'check-in',
          apartamento: reserva.apartamento.nome,
          hospede: reserva.hospede.nome,
          data: format(reserva.dataInicio, "dd/MM 'às' HH:mm", { locale: ptBR })
        });
      }
      
      // Check-out
      if (reserva.dataFim >= now && reserva.status === 'CHECK_IN') {
        proximosEventos.push({
          id: `${reserva.id}-checkout`,
          tipo: 'check-out',
          apartamento: reserva.apartamento.nome,
          hospede: reserva.hospede.nome,
          data: format(reserva.dataFim, "dd/MM 'às' HH:mm", { locale: ptBR })
        });
      }
    });

    // Ordenar eventos por data
    proximosEventos.sort((a, b) => {
      const dateA = new Date(a.data.replace(/(\d{2})\/(\d{2}) às (\d{2}):(\d{2})/, `2024-$2-$1T$3:$4:00`));
      const dateB = new Date(b.data.replace(/(\d{2})\/(\d{2}) às (\d{2}):(\d{2})/, `2024-$2-$1T$3:$4:00`));
      return dateA.getTime() - dateB.getTime();
    });

    // Resumo financeiro do mês
    const reservasMes = await prisma.reserva.findMany({
      where: {
        OR: [
          {
            dataInicio: { gte: startMonth, lte: endMonth }
          },
          {
            dataFim: { gte: startMonth, lte: endMonth }
          },
          {
            dataInicio: { lte: startMonth },
            dataFim: { gte: endMonth }
          }
        ],
        status: { in: ['CONFIRMADA', 'CHECK_IN', 'CHECK_OUT'] }
      }
    });

    const despesasMes = await prisma.despesa.findMany({
      where: {
        data: { gte: startMonth, lte: endMonth }
      }
    });

    const receitaMes = reservasMes.reduce((total, reserva) => {
      const inicio = reserva.dataInicio > startMonth ? reserva.dataInicio : startMonth;
      const fim = reserva.dataFim < endMonth ? reserva.dataFim : endMonth;
      const diasNoMes = Math.max(1, differenceInDays(fim, inicio) + 1);
      const diasTotal = differenceInDays(reserva.dataFim, reserva.dataInicio) + 1;
      const valorProporcional = (Number(reserva.preco) / diasTotal) * diasNoMes;
      return total + valorProporcional;
    }, 0);

    const despesaMes = despesasMes.reduce((total, despesa) => total + Number(despesa.valor), 0);
    const lucroMes = receitaMes - despesaMes;

    // Taxa de ocupação do mês
    const totalDiasDisponiveis = apartamentos.length * differenceInDays(endMonth, startMonth);
    const diasOcupados = reservasMes.reduce((total, reserva) => {
      const inicio = reserva.dataInicio > startMonth ? reserva.dataInicio : startMonth;
      const fim = reserva.dataFim < endMonth ? reserva.dataFim : endMonth;
      return total + Math.max(0, differenceInDays(fim, inicio) + 1);
    }, 0);
    
    const ocupacaoMes = totalDiasDisponiveis > 0 ? (diasOcupados / totalDiasDisponiveis) * 100 : 0;

    // Tarefas pendentes
    const tarefasPendentes = await prisma.tarefa.findMany({
      where: {
        status: { in: ['PENDENTE', 'EM_ANDAMENTO'] },
        data: { gte: now }
      },
      include: {
        apartamento: true
      },
      orderBy: { data: 'asc' },
      take: 10
    });

    const tarefasData = tarefasPendentes.map(tarefa => ({
      id: tarefa.id,
      titulo: tarefa.titulo,
      apartamento: tarefa.apartamento.nome,
      data: format(tarefa.data, "dd/MM 'às' HH:mm", { locale: ptBR }),
      tipo: tarefa.tipo
    }));

    return NextResponse.json({
      apartamentos: apartamentosData,
      proximosEventos: proximosEventos.slice(0, 10),
      resumoFinanceiro: {
        receitaMes,
        despesasMes: despesaMes,
        lucroMes,
        ocupacaoMes
      },
      tarefasPendentes: tarefasData
    });

  } catch (error) {
    console.error('Erro ao buscar dados do dashboard:', error);
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
