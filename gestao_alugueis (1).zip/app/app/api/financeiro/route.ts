
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { startOfMonth, endOfMonth, subMonths, format, differenceInDays } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const periodo = parseInt(searchParams.get('periodo') || '3');

    const dataFim = new Date();
    const dataInicio = subMonths(dataFim, periodo);

    // Buscar reservas do período
    const reservas = await prisma.reserva.findMany({
      where: {
        OR: [
          {
            dataInicio: { gte: dataInicio, lte: dataFim }
          },
          {
            dataFim: { gte: dataInicio, lte: dataFim }
          },
          {
            dataInicio: { lte: dataInicio },
            dataFim: { gte: dataFim }
          }
        ],
        status: { in: ['CONFIRMADA', 'CHECK_IN', 'CHECK_OUT'] }
      },
      include: {
        apartamento: true
      }
    });

    // Buscar despesas do período
    const despesas = await prisma.despesa.findMany({
      where: {
        data: { gte: dataInicio, lte: dataFim }
      },
      include: {
        reserva: {
          include: {
            apartamento: true
          }
        }
      },
      orderBy: { data: 'desc' }
    });

    // Calcular resumo financeiro
    const receitaTotal = reservas.reduce((total, reserva) => {
      const inicio = reserva.dataInicio > dataInicio ? reserva.dataInicio : dataInicio;
      const fim = reserva.dataFim < dataFim ? reserva.dataFim : dataFim;
      const diasNoPeriodo = Math.max(1, differenceInDays(fim, inicio) + 1);
      const diasTotal = differenceInDays(reserva.dataFim, reserva.dataInicio) + 1;
      const valorProporcional = (Number(reserva.preco) / diasTotal) * diasNoPeriodo;
      return total + valorProporcional;
    }, 0);

    const despesaTotal = despesas.reduce((total, despesa) => total + Number(despesa.valor), 0);
    const lucro = receitaTotal - despesaTotal;

    // Calcular ocupação
    const apartamentos = await prisma.apartamento.findMany({ where: { ativo: true } });
    const totalDiasDisponiveis = apartamentos.length * differenceInDays(dataFim, dataInicio);
    const diasOcupados = reservas.reduce((total, reserva) => {
      const inicio = reserva.dataInicio > dataInicio ? reserva.dataInicio : dataInicio;
      const fim = reserva.dataFim < dataFim ? reserva.dataFim : dataFim;
      return total + Math.max(0, differenceInDays(fim, inicio) + 1);
    }, 0);
    const ocupacao = totalDiasDisponiveis > 0 ? (diasOcupados / totalDiasDisponiveis) * 100 : 0;

    // Receitas por mês
    const receitasPorMes: Array<{ mes: string; valor: number }> = [];
    for (let i = 0; i < periodo; i++) {
      const mesData = subMonths(dataFim, i);
      const inicioMes = startOfMonth(mesData);
      const fimMes = endOfMonth(mesData);
      
      const receitaMes = reservas
        .filter(reserva => 
          reserva.dataInicio <= fimMes && reserva.dataFim >= inicioMes
        )
        .reduce((total, reserva) => {
          const inicio = reserva.dataInicio > inicioMes ? reserva.dataInicio : inicioMes;
          const fim = reserva.dataFim < fimMes ? reserva.dataFim : fimMes;
          const diasNoMes = Math.max(1, differenceInDays(fim, inicio) + 1);
          const diasTotal = differenceInDays(reserva.dataFim, reserva.dataInicio) + 1;
          const valorProporcional = (Number(reserva.preco) / diasTotal) * diasNoMes;
          return total + valorProporcional;
        }, 0);

      receitasPorMes.unshift({
        mes: format(mesData, 'MMM/yy', { locale: ptBR }),
        valor: receitaMes
      });
    }

    // Despesas por categoria
    const despesasPorCategoria = despesas.reduce((acc, despesa) => {
      const categoria = despesa.categoria;
      const existing = acc.find(item => item.categoria === categoria);
      if (existing) {
        existing.valor += Number(despesa.valor);
      } else {
        acc.push({
          categoria,
          valor: Number(despesa.valor)
        });
      }
      return acc;
    }, [] as Array<{ categoria: string; valor: number }>);

    // Ocupação por apartamento
    const ocupacaoPorApartamento = apartamentos.map(apt => {
      const reservasApt = reservas.filter(r => r.apartamentoId === apt.id);
      const diasOcupadosApt = reservasApt.reduce((total, reserva) => {
        const inicio = reserva.dataInicio > dataInicio ? reserva.dataInicio : dataInicio;
        const fim = reserva.dataFim < dataFim ? reserva.dataFim : dataFim;
        return total + Math.max(0, differenceInDays(fim, inicio) + 1);
      }, 0);
      const diasDisponiveisApt = differenceInDays(dataFim, dataInicio);
      const ocupacaoApt = diasDisponiveisApt > 0 ? (diasOcupadosApt / diasDisponiveisApt) * 100 : 0;
      
      return {
        apartamento: apt.nome,
        ocupacao: ocupacaoApt
      };
    });

    // Transações recentes (últimas 20)
    const transacoes = [
      ...reservas.map(reserva => ({
        id: reserva.id,
        tipo: 'receita' as const,
        descricao: `Reserva - ${reserva.apartamento.nome}`,
        valor: Number(reserva.preco),
        data: reserva.dataInicio.toISOString(),
        apartamento: reserva.apartamento.nome
      })),
      ...despesas.map(despesa => ({
        id: despesa.id,
        tipo: 'despesa' as const,
        descricao: despesa.descricao,
        valor: Number(despesa.valor),
        data: despesa.data.toISOString(),
        categoria: despesa.categoria,
        apartamento: despesa.reserva?.apartamento?.nome
      }))
    ].sort((a, b) => new Date(b.data).getTime() - new Date(a.data).getTime()).slice(0, 20);

    return NextResponse.json({
      resumo: {
        receitaTotal,
        despesaTotal,
        lucro,
        ocupacao
      },
      receitasPorMes,
      despesasPorCategoria,
      ocupacaoPorApartamento,
      transacoes
    });

  } catch (error) {
    console.error('Erro ao buscar dados financeiros:', error);
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
