
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { mapeamentos, ativa } = body;

    // Buscar integração Booking.com
    const integracao = await prisma.integracao.findFirst({
      where: {
        plataforma: 'BOOKING_COM',
      },
    });

    if (!integracao) {
      return NextResponse.json(
        { error: 'Integração não encontrada' },
        { status: 404 }
      );
    }

    // Atualizar configurações da integração
    await prisma.integracao.update({
      where: {
        id: integracao.id,
      },
      data: {
        ativa: ativa,
      },
    });

    // Deletar mapeamentos existentes
    await prisma.mapeamentoApartamento.deleteMany({
      where: {
        integracaoId: integracao.id,
      },
    });

    // Criar novos mapeamentos
    const novosMapeamentos = [];
    for (const [apartamentoId, idExterno] of Object.entries(mapeamentos)) {
      if (idExterno && idExterno !== '') {
        // Buscar dados do anúncio externo (simulado)
        const anunciosExternos = {
          'booking_001': 'Ocean View Apartment - Copacabana Beach',
          'booking_002': 'Modern Loft in Ipanema',
          'booking_003': 'Luxury Penthouse - Barra da Tijuca',
          'booking_004': 'Cozy Studio near Leblon Beach',
        };

        novosMapeamentos.push({
          integracaoId: integracao.id,
          apartamentoId: apartamentoId,
          idExterno: idExterno as string,
          nomeExterno: anunciosExternos[idExterno as keyof typeof anunciosExternos] || 'Anúncio Booking.com',
        });
      }
    }

    if (novosMapeamentos.length > 0) {
      await prisma.mapeamentoApartamento.createMany({
        data: novosMapeamentos,
      });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Erro ao configurar Booking.com:', error);
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
