
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const integracoes = await prisma.integracao.findMany({
      include: {
        mapeamentos: {
          include: {
            apartamento: true,
          },
        },
        _count: {
          select: {
            reservasSync: true,
          },
        },
      },
    });

    return NextResponse.json(integracoes);
  } catch (error) {
    console.error('Erro ao buscar integrações:', error);
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
