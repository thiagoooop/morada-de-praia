
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { token } = body;

    // Verificar se já existe uma integração Airbnb
    const integracaoExistente = await prisma.integracao.findFirst({
      where: {
        plataforma: 'AIRBNB',
      },
    });

    let integracao;

    if (integracaoExistente) {
      // Atualizar integração existente
      integracao = await prisma.integracao.update({
        where: {
          id: integracaoExistente.id,
        },
        data: {
          status: 'CONECTADA',
          nomeConexao: 'Conta Demo Airbnb',
          configuracao: {
            token: token,
            conectadoEm: new Date().toISOString(),
          },
          ultimaSync: new Date(),
        },
        include: {
          mapeamentos: {
            include: {
              apartamento: true,
            },
          },
        },
      });
    } else {
      // Criar nova integração
      integracao = await prisma.integracao.create({
        data: {
          plataforma: 'AIRBNB',
          nomeConexao: 'Conta Demo Airbnb',
          status: 'CONECTADA',
          configuracao: {
            token: token,
            conectadoEm: new Date().toISOString(),
          },
          ultimaSync: new Date(),
          ativa: false,
        },
        include: {
          mapeamentos: {
            include: {
              apartamento: true,
            },
          },
        },
      });
    }

    return NextResponse.json(integracao);
  } catch (error) {
    console.error('Erro ao conectar Airbnb:', error);
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
