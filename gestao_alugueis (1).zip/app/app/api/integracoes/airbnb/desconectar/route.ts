
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export async function POST() {
  try {
    // Buscar integração Airbnb
    const integracao = await prisma.integracao.findFirst({
      where: {
        plataforma: 'AIRBNB',
      },
    });

    if (!integracao) {
      return NextResponse.json(
        { error: 'Integração não encontrada' },
        { status: 404 }
      );
    }

    // Deletar mapeamentos e reservas sincronizadas
    await prisma.$transaction([
      prisma.reservaSincronizada.deleteMany({
        where: {
          integracaoId: integracao.id,
        },
      }),
      prisma.mapeamentoApartamento.deleteMany({
        where: {
          integracaoId: integracao.id,
        },
      }),
      prisma.integracao.delete({
        where: {
          id: integracao.id,
        },
      }),
    ]);

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Erro ao desconectar Airbnb:', error);
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
