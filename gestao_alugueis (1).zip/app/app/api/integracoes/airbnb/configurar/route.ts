
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { mapeamentos, ativa } = body;

    // Buscar integração Airbnb
    const integracao = await prisma.integracao.findFirst({
      where: {
        plataforma: 'AIRBNB',
      },
    });

    if (!integracao) {
      return NextResponse.json(
        { error: 'Integração não encontrada' },
        { status: 404 }
      );
    }

    // Atualizar configurações da integração
    await prisma.integracao.update({
      where: {
        id: integracao.id,
      },
      data: {
        ativa: ativa,
      },
    });

    // Deletar mapeamentos existentes
    await prisma.mapeamentoApartamento.deleteMany({
      where: {
        integracaoId: integracao.id,
      },
    });

    // Criar novos mapeamentos
    const novosMapeamentos = [];
    for (const [apartamentoId, idExterno] of Object.entries(mapeamentos)) {
      if (idExterno && idExterno !== '') {
        // Buscar dados do anúncio externo (simulado)
        const anunciosExternos = {
          'airbnb_001': 'Apartamento Vista Mar - Copacabana',
          'airbnb_002': 'Loft Moderno - Ipanema',
          'airbnb_003': 'Cobertura Duplex - Barra da Tijuca',
          'airbnb_004': 'Studio Aconchegante - Leblon',
        };

        novosMapeamentos.push({
          integracaoId: integracao.id,
          apartamentoId: apartamentoId,
          idExterno: idExterno as string,
          nomeExterno: anunciosExternos[idExterno as keyof typeof anunciosExternos] || 'Anúncio Airbnb',
        });
      }
    }

    if (novosMapeamentos.length > 0) {
      await prisma.mapeamentoApartamento.createMany({
        data: novosMapeamentos,
      });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Erro ao configurar Airbnb:', error);
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
