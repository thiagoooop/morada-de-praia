
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const tarefas = await prisma.tarefa.findMany({
      include: {
        apartamento: {
          select: { id: true, nome: true }
        }
      },
      orderBy: [
        { status: 'asc' },
        { data: 'asc' }
      ]
    });

    return NextResponse.json(tarefas);
  } catch (error) {
    console.error('Erro ao buscar tarefas:', error);
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const data = await request.json();
    
    const tarefa = await prisma.tarefa.create({
      data: {
        titulo: data.titulo,
        descricao: data.descricao,
        apartamentoId: data.apartamentoId,
        data: new Date(data.data),
        tipo: data.tipo,
        status: data.status || 'PENDENTE'
      },
      include: {
        apartamento: {
          select: { id: true, nome: true }
        }
      }
    });

    return NextResponse.json(tarefa, { status: 201 });
  } catch (error) {
    console.error('Erro ao criar tarefa:', error);
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
