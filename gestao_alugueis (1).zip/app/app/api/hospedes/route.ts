
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const hospedes = await prisma.hospede.findMany({
      include: {
        _count: {
          select: { reservas: true }
        },
        reservas: {
          select: { dataFim: true },
          orderBy: { dataFim: 'desc' },
          take: 1
        }
      },
      orderBy: { nome: 'asc' }
    });

    // Formatar dados para incluir última estadia
    const hospedesFormatted = hospedes.map(hospede => ({
      ...hospede,
      ultimaEstadia: hospede.reservas[0]?.dataFim || null,
      reservas: undefined // Remover o array completo de reservas
    }));

    return NextResponse.json(hospedesFormatted);
  } catch (error) {
    console.error('Erro ao buscar hóspedes:', error);
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const data = await request.json();
    
    const hospede = await prisma.hospede.create({
      data: {
        nome: data.nome,
        email: data.email,
        telefone: data.telefone,
        documento: data.documento,
        observacoes: data.observacoes
      }
    });

    return NextResponse.json(hospede, { status: 201 });
  } catch (error) {
    console.error('Erro ao criar hóspede:', error);
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
