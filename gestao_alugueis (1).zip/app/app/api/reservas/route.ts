
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const inicio = searchParams.get('inicio');
    const fim = searchParams.get('fim');
    const apartamentoId = searchParams.get('apartamentoId');

    let whereClause: any = {};

    if (inicio && fim) {
      whereClause.OR = [
        {
          dataInicio: {
            gte: new Date(inicio),
            lte: new Date(fim)
          }
        },
        {
          dataFim: {
            gte: new Date(inicio),
            lte: new Date(fim)
          }
        },
        {
          dataInicio: { lte: new Date(inicio) },
          dataFim: { gte: new Date(fim) }
        }
      ];
    }

    if (apartamentoId) {
      whereClause.apartamentoId = apartamentoId;
    }

    const reservas = await prisma.reserva.findMany({
      where: whereClause,
      include: {
        apartamento: {
          select: { id: true, nome: true }
        },
        hospede: {
          select: { id: true, nome: true, email: true, telefone: true }
        },
        sincronizacao: {
          select: {
            id: true,
            idExterno: true,
            integracao: {
              select: {
                plataforma: true,
                nomeConexao: true
              }
            }
          }
        }
      },
      orderBy: { dataInicio: 'asc' }
    });

    // Converter Decimal para number para serialização JSON
    const reservasFormatted = reservas.map(reserva => ({
      ...reserva,
      preco: Number(reserva.preco)
    }));

    return NextResponse.json(reservasFormatted);
  } catch (error) {
    console.error('Erro ao buscar reservas:', error);
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const data = await request.json();
    
    const reserva = await prisma.reserva.create({
      data: {
        apartamentoId: data.apartamentoId,
        hospedeId: data.hospedeId,
        dataInicio: new Date(data.dataInicio),
        dataFim: new Date(data.dataFim),
        preco: parseFloat(data.preco),
        status: data.status || 'CONFIRMADA',
        observacoes: data.observacoes
      },
      include: {
        apartamento: {
          select: { id: true, nome: true }
        },
        hospede: {
          select: { id: true, nome: true, email: true, telefone: true }
        }
      }
    });

    // Converter Decimal para number
    const reservaFormatted = {
      ...reserva,
      preco: Number(reserva.preco)
    };

    return NextResponse.json(reservaFormatted, { status: 201 });
  } catch (error) {
    console.error('Erro ao criar reserva:', error);
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
