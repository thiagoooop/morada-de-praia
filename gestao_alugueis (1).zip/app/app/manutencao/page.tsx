
import { getServerSession } from 'next-auth';
import { redirect } from 'next/navigation';
import { DashboardLayout } from '@/components/dashboard-layout';
import { ManutencaoManager } from '@/components/manutencao-manager';

export default async function ManutencaoPage() {
  const session = await getServerSession();

  if (!session) {
    redirect('/login');
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Calendário de Manutenção</h1>
            <p className="text-muted-foreground">
              Agenda de limpeza, manutenção e tarefas gerais
            </p>
          </div>
        </div>
        <ManutencaoManager />
      </div>
    </DashboardLayout>
  );
}
